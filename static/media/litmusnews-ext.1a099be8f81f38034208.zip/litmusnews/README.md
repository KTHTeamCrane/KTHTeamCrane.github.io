# How to install the extension
### Ensure Developer mode has been enabled.

0. If Developer mode has not been enabled, navigate to [chrome://extensions](chrome://extensions) and toggle Developer mode.
1. Go to the Admin console and access "Devices" > "Chrome" > "Apps and extensions" > "Users and browsers"
2. Look for "Additional Settings" on the right
3. Select the user/browser (in case of managed browsers) OU.
4. Set the policy "Allow insecure extension packaging" to allow. 
5. Set "External extensions" to be allowed also. 
6. Save the changes. 

For more info, see [How to load unpacked or unsafe extensions](https://knowledge.workspace.google.com/kb/load-unpacked-extensions-000005962).